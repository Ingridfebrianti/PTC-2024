export const BASE_URL = import.meta.env.VITE_BASE_API_URL;
export const ATTANDANCE_URL= import.meta.env.VITE_ATTANDANCE_API_URL