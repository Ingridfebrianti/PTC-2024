// Import Firebase SDK
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";
import { getDatabase, ref, set } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-database.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDkhmHrGsh9dqS5Mt8HTvPBOzcS4V4juuo",
  authDomain: "smart-presensi-ith.firebaseapp.com",
  databaseURL: "https://smart-presensi-ith-default-rtdb.firebaseio.com",
  projectId: "smart-presensi-ith",
  storageBucket: "smart-presensi-ith.firebasestorage.app",
  messagingSenderId: "371251022577",
  appId: "1:371251022577:web:2ef077cc43bb65ee16b750",
  measurementId: "G-WS0EX2V5L7"
};

// Initialize Firebase app
const app = initializeApp(firebaseConfig);

// Get references to Firebase services
const auth = getAuth(app);
const database = getDatabase(app);

// Handle form submission for registration
const daftarForm = document.getElementById('daftar-form');
daftarForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const namaLengkap = document.getElementById('nama_lengkap').value;
  const nidn = document.getElementById('nidn').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('kata_sandi').value;
  const confirmPassword = document.getElementById('konfirmasi_sandi').value;

  // Password validation
  if (password.length < 6) {
    alert('Password harus minimal 6 karakter!');
    return;
  }

  // Check if passwords match
  if (password !== confirmPassword) {
    alert('Password tidak sama!');
    return;
  }

  // Create user with email and password
  createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      const user = userCredential.user;
      const userId = user.uid;

      // Save user data to Realtime Database
      const userData = {
        namaLengkap,
        nidn,
        email
      };
      set(ref(database, 'users/' + userId), userData)
        .then(() => {
          alert('Registrasi berhasil!');
          // Redirect to login page after successful registration
          window.location.href = "Masuk.html";
        })
        .catch((error) => {
          alert('Error saving user data:', error.message);
        });
    })
    .catch((error) => {
      const errorCode = error.code;
      const errorMessage = error.message;
      
      if (errorCode === 'auth/email-already-in-use') {
        alert('Email sudah terdaftar!');
      } else {
        alert('Error creating user: ' + errorMessage);
      }
    });
});
