// Mengatur navigasi halaman
function showPage(pageId) {
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.add('hidden'));

    document.getElementById(pageId).classList.remove('hidden');
    const menuItems = document.querySelectorAll('.sidebar li');
    menuItems.forEach(item => item.classList.remove('active'));
    document.querySelector(`[onclick="showPage('${pageId}')"]`).classList.add('active');
}


