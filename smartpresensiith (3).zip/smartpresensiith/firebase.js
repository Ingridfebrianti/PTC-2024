// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDkhmHrGsh9dqS5Mt8HTvPBOzcS4V4juuo",
    authDomain: "smart-presensi-ith.firebaseapp.com",
    databaseURL: "https://smart-presensi-ith-default-rtdb.firebaseio.com",
    projectId: "smart-presensi-ith",
    storageBucket: "smart-presensi-ith.appspot.com",
    messagingSenderId: "371251022577",
    appId: "1:371251022577:web:2ef077cc43bb65ee16b750",
    measurementId: "G-WS0EX2V5L7"
  };
  
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  const database = firebase.database();
  
  // Function to add a class to Firebase
  const addClassToFirebase = (lecturer, course, cls) => {
    const newClassRef = database.ref('classes').push();
    newClassRef.set({
      lecturer: lecturer,
      course: course,
      className: cls
    });
  };
  
  // Function to fetch classes from Firebase
  const fetchClassesFromFirebase = () => {
    database.ref('classes').on('value', (snapshot) => {
      const classes = snapshot.val();
      const classList = document.getElementById('classListContent');
      classList.innerHTML = ''; // Clear current list
      for (const key in classes) {
        const { lecturer, course, className } = classes[key];
        addClassCard(lecturer, course, className);
      }
      updateEmptyState();
    });
  };
  