
// Konfigurasi Firebase
const firebaseConfig = {
    apiKey: "AIzaSyDkhmHrGsh9dqS5Mt8HTvPBOzcS4V4juuo",
    authDomain: "smart-presensi-ith.firebaseapp.com",
    databaseURL: "https://smart-presensi-ith-default-rtdb.firebaseio.com",
    projectId: "smart-presensi-ith",
    storageBucket: "smart-presensi-ith.firebasestorage.app",
    messagingSenderId: "371251022577",
    appId: "1:371251022577:web:2ef077cc43bb65ee16b750",
    measurementId: "G-WS0EX2V5L7"
};

// Inisialisasi Firebase
firebase.initializeApp(firebaseConfig);

// Mendapatkan referensi ke database
const database = firebase.database();

// Fungsi untuk menampilkan atau menyembunyikan form buat kelas
function toggleForm() {
    const formContainer = document.getElementById('kelasFormContainer');
    formContainer.classList.toggle('active');
}

// Menangani pengiriman form
document.getElementById('kelasForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    // Mengambil data form
    const namaDosen = document.getElementById('namaDosen').value;
    const mataKuliah = document.getElementById('mataKuliah').value;
    const kelas = document.getElementById('kelas').value;

    // Menyimpan data kelas ke Firebase
    const kelasRef = database.ref('kelas'); // Referensi ke node 'kelas'
    const newKelasRef = kelasRef.push(); // Menambahkan data baru
    newKelasRef.set({
        namaDosen: namaDosen,
        mataKuliah: mataKuliah,
        kelas: kelas
    }).then(() => {
        // Menambahkan elemen kelas baru ke daftar kelas
        const kelasList = document.getElementById('kelasList');
        const kelasItem = document.createElement('div');
        kelasItem.className = 'kelas-item';
        kelasItem.innerHTML = `
            <div>
                <h5>${mataKuliah}</h5>
                <p>${kelas}</p>
            </div>
            <p>${namaDosen}</p>
        `;
        kelasItem.addEventListener('click', function() {
            navigateToDetail(mataKuliah, kelas);
        });
        kelasList.appendChild(kelasItem);

        // Reset form setelah disubmit
        document.getElementById('kelasForm').reset();
        toggleForm(); // Menyembunyikan form setelah submit
    }).catch((error) => {
        console.error("Error menambahkan kelas: ", error);
    });
});

// Navigasi ke detail kelas
function navigateToDetail(nama, kode) {
    document.getElementById('kelasNama').textContent = nama;
    document.getElementById('kelasKode').textContent = kode;

    document.getElementById('kelasFormContainer').style.display = 'none';
    document.getElementById('kelasList').style.display = 'none';
    document.getElementById('createClassButton').style.display = 'none';
    document.getElementById('detailKelasContainer').style.display = 'block';
}

function showTab(tab) {
    const aktivitas = document.getElementById('contentAktivitas');
    const peserta = document.getElementById('contentPeserta');
    const tabAktivitas = document.getElementById('tabAktivitas');
    const tabPeserta = document.getElementById('tabPeserta');

    if (tab === 'aktivitas') {
        aktivitas.style.display = 'block';
        peserta.style.display = 'none';
        tabAktivitas.classList.add('active');
        tabPeserta.classList.remove('active');
    } else {
        aktivitas.style.display = 'none';
        peserta.style.display = 'block';
        tabAktivitas.classList.remove('active');
        tabPeserta.classList.add('active');
    }
}

