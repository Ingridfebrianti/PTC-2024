// Import Firebase modular SDK
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.17.2/firebase-app.js";
import { getDatabase, ref, push, onValue, set } from "https://www.gstatic.com/firebasejs/9.17.2/firebase-database.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDkhmHrGsh9dqS5Mt8HTvPBOzcS4V4juuo",
    authDomain: "smart-presensi-ith.firebaseapp.com",
    databaseURL: "https://smart-presensi-ith-default-rtdb.firebaseio.com", // URL Realtime Database
    projectId: "smart-presensi-ith",
    storageBucket: "smart-presensi-ith.firebasestorage.app",
    messagingSenderId: "371251022577",
    appId: "1:371251022577:web:2ef077cc43bb65ee16b750",
    measurementId: "G-WS0EX2V5L7"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

document.addEventListener("DOMContentLoaded", () => {
    const classList = document.getElementById("classList");
    const classDetail = document.getElementById("classDetail");
    const classDetailTitle = document.getElementById("classDetailTitle");
    const classListContent = document.getElementById("classListContent");
    const emptyState = document.getElementById("emptyState");

    const createClassForm = document.getElementById("createClassForm");
    const lecturerNameInput = document.getElementById("lecturerName");
    const courseNameInput = document.getElementById("courseName");
    const classNameInput = document.getElementById("className");

    const backToClassListButton = document.getElementById("backToClassList");

    // Variables for meeting
    const meetingForm = document.getElementById("createMeetingForm");
    const meetingTitleInput = document.getElementById("meetingTitle");
    const meetingTimeInput = document.getElementById("meetingTime");
    const createMeetingButton = document.querySelector("#pertemuan .btn-create-class");
    let selectedClassId = null; // Save selected class ID

    // Tab navigation
    const tabs = document.querySelectorAll(".tab");
    const tabContents = document.querySelectorAll(".tab-content");

    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            tabs.forEach(t => t.classList.remove("active"));
            tabContents.forEach(content => content.classList.remove("active"));

            tab.classList.add("active");
            document.getElementById(tab.getAttribute("data-tab")).classList.add("active");
        });
    });

    // Show class detail
    function showClassDetail(classTitle, classId) {
        classList.style.display = "none";
        classDetail.style.display = "block";
        classDetailTitle.textContent = classTitle;
        selectedClassId = classId; // Save class ID for meeting
    }

    // Return to class list
    backToClassListButton.addEventListener("click", () => {
        classList.style.display = "block";
        classDetail.style.display = "none";
    });

    // Load existing classes from Firebase
    const classesRef = ref(database, "classes");
    onValue(classesRef, (snapshot) => {
        classListContent.innerHTML = "";
        if (snapshot.exists()) {
            emptyState.style.display = "none";
            snapshot.forEach((childSnapshot) => {
                const classId = childSnapshot.key; // Get class ID
                const classData = childSnapshot.val();
                const classItem = document.createElement("div");
                classItem.className = "class-item card p-3 mb-3";
                classItem.innerHTML = `
                    <h5>${classData.courseName} - ${classData.className}</h5>
                    <p>Dosen: ${classData.lecturerName}</p>
                `;
                classItem.addEventListener("click", () => {
                    showClassDetail(`${classData.courseName} - ${classData.className}`, classId);
                });
                classListContent.appendChild(classItem);
            });
        } else {
            emptyState.style.display = "block";
        }
    });

    // Handle form submission for creating a class
    createClassForm.addEventListener("submit", (e) => {
        e.preventDefault();

        const lecturerName = lecturerNameInput.value.trim();
        const courseName = courseNameInput.value.trim();
        const className = classNameInput.value.trim();

        if (lecturerName && courseName && className) {
            const newClassRef = push(classesRef);
            set(newClassRef, {
                lecturerName,
                courseName,
                className
            }).then(() => {
                createClassForm.reset();
                const createClassModal = bootstrap.Modal.getInstance(document.getElementById("createClassModal"));
                createClassModal.hide();
            }).catch((error) => {
                console.error("Error saving class:", error);
            });
        }
    });

// Show modal for creating meeting
createMeetingButton.addEventListener("click", () => {
    const createMeetingModal = new bootstrap.Modal(document.getElementById("createMeetingModal"));
    createMeetingModal.show();
});

// Handle form submission for creating a meeting
meetingForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const meetingTitle = meetingTitleInput.value.trim();
    const meetingTime = meetingTimeInput.value;

    if (selectedClassId && meetingTitle && meetingTime) {
        const meetingsRef = ref(database, `classes/${selectedClassId}/meetings`);
        const newMeetingRef = push(meetingsRef);

        set(newMeetingRef, {
            meetingTitle,
            meetingTime,
        }).then(() => {
            // After the meeting is created, generate the QR code
            const classRef = ref(database, `classes/${selectedClassId}`);
            onValue(classRef, (snapshot) => {
                if (snapshot.exists()) {
                    const classData = snapshot.val();
                    const qrData = {
                        courseName: classData.courseName,
                        className: classData.className,
                        lecturerName: classData.lecturerName,
                        meetingTitle: meetingTitle,
                        meetingTime: meetingTime
                    };

                    // Generate QR Code
                    QRCode.toCanvas(document.getElementById("qrCanvas"), JSON.stringify(qrData), (error) => {
                        if (error) console.error(error);
                        console.log("QR Code generated successfully!");
                    });
                }
            });

            meetingForm.reset();
            const createMeetingModal = bootstrap.Modal.getInstance(document.getElementById("createMeetingModal"));
            createMeetingModal.hide();
        }).catch((error) => {
            console.error("Error saving meeting:", error);
        });
    }
});

// Show class detail with meetings and generate QR code for selected meeting
function showClassDetail(classTitle, classId) {
    classList.style.display = "none";
    classDetail.style.display = "block";
    classDetailTitle.textContent = classTitle;
    selectedClassId = classId; // Save class ID for meeting

    // Load meetings for the selected class
    const meetingsRef = ref(database, `classes/${selectedClassId}/meetings`);
    const pertemuanTab = document.getElementById("pertemuan");

    // Clear and reset tab content
    pertemuanTab.innerHTML = `
        <button id="btn-create-meeting" class="btn btn-primary mb-3">Buat Pertemuan</button>
        <div id="meeting-list"></div>
    `;

    // Add event listener for creating a meeting
    const createMeetingButton = document.getElementById("btn-create-meeting");
    createMeetingButton.addEventListener("click", () => {
        const createMeetingModal = new bootstrap.Modal(document.getElementById("createMeetingModal"));
        createMeetingModal.show();
    });

    // Append meeting list
    onValue(meetingsRef, (snapshot) => {
        const meetingList = document.getElementById("meeting-list");
        meetingList.innerHTML = ''; // Clear existing meetings

        if (snapshot.exists()) {
            snapshot.forEach((childSnapshot) => {
                const meetingData = childSnapshot.val();
                const meetingItem = document.createElement("div");
                meetingItem.className = "meeting-item card p-3 mb-3";
                meetingItem.innerHTML = `
                    <h5>${meetingData.meetingTitle}</h5>
                    <p>Waktu: ${meetingData.meetingTime}</p>
                    <button class="btn btn-info btn-sm" data-meeting-id="${childSnapshot.key}">Lihat QR Code</button>
                `;

                // Event listener for showing QR code
                const qrButton = meetingItem.querySelector("button");
                qrButton.addEventListener("click", () => {
                    // Generate QR code when clicked
                    const qrData = {
                        courseName: classTitle.split(" - ")[0],  // Assuming classTitle format is "Course - Class"
                        className: classTitle.split(" - ")[1],
                        lecturerName: meetingData.lecturerName,
                        meetingTitle: meetingData.meetingTitle,
                        meetingTime: meetingData.meetingTime
                    };

                    // Generate QR Code and display it
                    const qrCanvas = document.createElement("canvas");
                    QRCode.toCanvas(qrCanvas, JSON.stringify(qrData), (error) => {
                        if (error) console.error(error);
                        console.log("QR Code generated successfully!");
                    });

                    // Show QR code
                    const qrCodeModal = new bootstrap.Modal(document.getElementById("qrCodeModal"));
                    const qrCodeContainer = document.getElementById("qrCodeContainer");
                    qrCodeContainer.innerHTML = '';  // Clear previous QR code
                    qrCodeContainer.appendChild(qrCanvas);
                    qrCodeModal.show();
                });

                meetingList.appendChild(meetingItem);
            });
        } else {
            meetingList.innerHTML = "<p>Belum ada pertemuan untuk kelas ini.</p>";
        }
    });
}
});