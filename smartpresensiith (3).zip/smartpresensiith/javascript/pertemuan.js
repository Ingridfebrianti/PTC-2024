// Firebase Configuration (gunakan konfigurasi yang sama seperti di kelas.js)
const firebaseConfig = {
    apiKey: "AIzaSyDkhmHrGsh9dqS5Mt8HTvPBOzcS4V4juuo",
    authDomain: "smart-presensi-ith.firebaseapp.com",
    databaseURL: "https://smart-presensi-ith-default-rtdb.firebaseio.com",
    projectId: "smart-presensi-ith",
    storageBucket: "smart-presensi-ith.firebasestorage.app",
    messagingSenderId: "371251022577",
    appId: "1:371251022577:web:2ef077cc43bb65ee16b750",
    measurementId: "G-WS0EX2V5L7"
};

// Initialize Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.1.0/firebase-app.js";
import { getDatabase, ref, onValue } from "https://www.gstatic.com/firebasejs/9.1.0/firebase-database.js";

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// Ambil ID kelas yang dipilih dari sessionStorage
const selectedClassId = sessionStorage.getItem('selectedClassId');

// Tampilkan informasi kelas
function displayClassInfo() {
    if (!selectedClassId) {
        alert('Tidak ada kelas yang dipilih.');
        return;
    }

    const classRef = ref(db, 'kelas/' + selectedClassId);

    onValue(classRef, (snapshot) => {
        if (snapshot.exists()) {
            const classData = snapshot.val();
            document.getElementById('classInfo').innerHTML = `
                <h1>${classData.nama_matakuliah}</h1>
                <h2>Kelas: ${classData.nama_kelas}</h2>
                <p>Jadwal: ${classData.jadwal}</p>
            `;
        } else {
            document.getElementById('classInfo').innerHTML = '<p>Kelas tidak ditemukan.</p>';
        }
    });
}

// Panggil fungsi untuk menampilkan informasi kelas saat halaman dimuat
window.onload = displayClassInfo;
