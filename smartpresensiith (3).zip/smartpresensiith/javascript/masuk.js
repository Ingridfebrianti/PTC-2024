import { initializeApp } from "https://www.gstatic.com/firebasejs/9.1.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.1.0/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDkhmHrGsh9dqS5Mt8HTvPBOzcS4V4juuo",
  authDomain: "smart-presensi-ith.firebaseapp.com",
  databaseURL: "https://smart-presensi-ith-default-rtdb.firebaseio.com",
  projectId: "smart-presensi-ith",
  storageBucket: "smart-presensi-ith.firebasestorage.app",
  messagingSenderId: "371251022577",
  appId: "1:371251022577:web:2ef077cc43bb65ee16b750",
  measurementId: "G-WS0EX2V5L7"
};

// Inisialisasi Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Fungsi untuk login pengguna
document.getElementById('loginForm').addEventListener('submit', function(event) {
  event.preventDefault(); // Mencegah form dari pengiriman default

  const username = document.getElementById('username').value; // Email
  const password = document.getElementById('password').value;

  // Login pengguna
  signInWithEmailAndPassword(auth, username, password)
    .then((userCredential) => {
      // Login berhasil
      const user = userCredential.user;
      alert("Login berhasil!");

      // Simpan uid ke sessionStorage
      sessionStorage.setItem('id_users', user.uid);

      // Arahkan pengguna ke halaman lain setelah login
      window.location.href = "index.html"; // Ganti dengan halaman yang sesuai
    })
    .catch((error) => {
      const errorCode = error.code;
      const errorMessage = error.message;
      console.error("Error during login: ", error);

      // Penanganan kesalahan spesifik
      if (errorCode === 'auth/user-not-found') {
        alert("NIDN tidak terdaftar. Silakan periksa kembali.");
      } else if (errorCode === 'auth/wrong-password') {
        alert("Kata sandi salah. Silakan coba lagi.");
      } else {
        alert("Login gagal: " + errorMessage);
      }
    });
});