// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyDkhmHrGsh9dqS5Mt8HTvPBOzcS4V4juuo",
    authDomain: "smart-presensi-ith.firebaseapp.com",
    databaseURL: "https://smart-presensi-ith-default-rtdb.firebaseio.com",
    projectId: "smart-presensi-ith",
    storageBucket: "smart-presensi-ith.firebasestorage.app",
    messagingSenderId: "371251022577",
    appId: "1:371251022577:web:2ef077cc43bb65ee16b750",
    measurementId: "G-WS0EX2V5L7"
};

// Initialize Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.1.0/firebase-app.js";
import { getDatabase, ref, set, onValue, query, orderByChild, equalTo } from "https://www.gstatic.com/firebasejs/9.1.0/firebase-database.js";

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// Get the user ID from sessionStorage
const currentUserId = sessionStorage.getItem('id_users');

// Function to display existing classes created by the logged-in user
function displayClasses() {
    const classListContainer = document.getElementById('classList');

    if (!currentUserId) {
        alert('User not logged in.');
        return;
    }

    const kelasRef = ref(db, 'kelas');
    const kelasQuery = query(kelasRef, orderByChild('id_users'), equalTo(currentUserId));

    onValue(kelasQuery, (snapshot) => {
        classListContainer.innerHTML = ''; // Clear previous content
        if (snapshot.exists()) {
            snapshot.forEach((childSnapshot) => {
                const classData = childSnapshot.val();
                const newClass = document.createElement('div');
                newClass.className = 'class-card';
                newClass.setAttribute('data-id', classData.id_kelas); // Menambahkan ID kelas di sini
                newClass.setAttribute('data-nama-matakuliah', classData.nama_matakuliah); // Menyimpan nama matakuliah
                newClass.setAttribute('data-nama-kelas', classData.nama_kelas); // Menyimpan nama kelas
                newClass.setAttribute('data-navigate', 'true');
                newClass.innerHTML = `
                    <h4>${classData.nama_matakuliah} - ${classData.nama_kelas}</h4>
                    <p>${classData.jadwal}</p>
                `;
                classListContainer.appendChild(newClass);
            });
        } else {
            classListContainer.innerHTML = '<p>No classes found.</p>';
        }
    });
}

// Function to save class data to Firebase
function submitForm() {
    const namaMatakuliah = document.getElementById('namaMatakuliah').value;
    const kelas = document.getElementById('kelas').value;
    const jadwal = document.getElementById('jadwal').value;

    if (namaMatakuliah && kelas && jadwal && currentUserId) {
        const newClassRef = ref(db, 'kelas/' + kelas); // Gunakan nama kelas sebagai ID unik

        const classData = {
            id_kelas: kelas,
            nama_matakuliah: namaMatakuliah,
            nama_kelas: kelas,
            id_users: currentUserId,
            jadwal: jadwal
        };

        set(newClassRef, classData)
            .then(() => {
                alert("Kelas berhasil dibuat!");
                // Simpan informasi kelas ke sessionStorage
                sessionStorage.setItem('currentClass', JSON.stringify(classData));
                displayClasses(); // Tampilkan kelas setelah berhasil disimpan
            })
            .catch((error) => {
                console.error('Error saat menyimpan data kelas:', error);
                alert("Gagal menyimpan kelas.");
            });

        // Reset form dan tutup modal
        document.getElementById('createClassForm').reset();
        const modal = bootstrap.Modal.getInstance(document.getElementById('createClassModal'));
        modal.hide();
    } else {
        alert('Harap isi semua kolom!');
    }
}

// Add event listener for "Save" button
document.getElementById('saveClassButton').addEventListener('click', submitForm);

// Ketika kelas diklik, simpan kelasId ke sessionStorage dan arahkan ke halaman pertemuan
document.getElementById('classList').addEventListener('click', (event) => {
    const classCard = event.target.closest('.class-card[data-navigate="true"]');
    if (classCard) {
        const classId = classCard.getAttribute('data-id');
        const namaMatakuliah = classCard.getAttribute('data-nama-matakuliah');
        const namaKelas = classCard.getAttribute('data-nama-kelas');
        
        // Simpan data ke sessionStorage
        sessionStorage.setItem('selectedClassId', classId); // Menyimpan ID kelas
        sessionStorage.setItem('selectedClass', JSON.stringify({
            nama_matakuliah: namaMatakuliah,
            nama_kelas: namaKelas
        })); // Menyimpan data nama mata kuliah dan nama kelas

        // Redirect ke halaman pertemuan
        window.location.href = 'pertemuan.html'; 
    }
});



// Call function to display classes when the page loads
window.onload = displayClasses;
